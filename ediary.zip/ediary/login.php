<?php
session_start();
require_once "functions.php";
require_once "db.php";
extract($_POST);
   
   if($_SERVER["REQUEST_METHOD"] == "POST") 
   {
      //username and password sent from form 
      
      $myusername = mysqli_real_escape_string($con,$_POST['uname']);
      $mypassword = sha1(mysqli_real_escape_string($con,$_POST['pass'])); 
      
      $sql = "SELECT id FROM users WHERE username = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($con,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
			
      if($count == 1) 
	  {
        
         $_SESSION['login_user'] = $myusername;
         header("location: http://localhost/ediary/main.php");
 
      }
	  else {
         $error = "Your Login Name or Password is invalid";
		 echo $error;
      }
   }
?>