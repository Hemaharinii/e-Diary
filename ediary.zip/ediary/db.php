<?php
$con= mysqli_connect('localhost','root','','diary');
if(!$con)
	exit("Connection Error");
?>