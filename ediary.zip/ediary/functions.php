﻿<?php
function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
return $data;}

 function ed_encrypt($data)
 {
	 $data=str_rot13($data);
	/* while(strlen($data)>strlen($name))
		 $name=$name.$name;
	 $data=$data^$name;*/
	 return $data;
 } 
 function ed_decrypt($data)
 {
	 /*while(strlen($data)>strlen($name))
		 $name=$name.$name;
	 $data=$data^$name;*/
	 $data=str_rot13($data);
	 $data=str_replace("\a","\n","$data");
	 $data=str_replace("\e","\r","$data");
	 
	 return $data;
 } 
  function Smilify(&$subject)
	{
		$smilies = array(
			':|'  => '😐',
			':-|' => '😐',
			':-o' => '😮',
			':-O' => '😮',
			':o'  => '😮',
			':O'  => '😮',
			';)'  => '😉',
			';-)' => '😉',
			':p'  => '😜',
			':-p' => '😜',
			':P'  => '😜',
			':-P' => '😜',
			':D'  => '😁',
			':-D' => '😁',
			'B)'  => '😎',
			'8-)' => '😎',
			':)'  => '😊',
			':-)' => '😊',
			':('  => '😞',
			':-(' => '😞',
			'-_-' => '😞',
			'<=3' => '😍',
			'<3' => '❤️',
			':toj' => '😂',
			'3:)' => '😈',
			':devil' => '👿'
			
		);

		$sizes = array(
			'biggrin' => 18,
			'cool' => 18,
			'haha' => 18,
			'mellow' => 18,
			'ohmy' => 18,
			'sad' => 18,
			'smile' => 18,
			'tongueout' => 18,
			'wink' => 18,
		);

		$replace = array();
		foreach ($smilies as $smiley => $imgName)
		{
			//$size = $sizes[$imgName];
			array_push($replace, $imgName);
		}
		$subject = str_replace(array_keys($smilies), $replace, $subject);
		return $subject;
	}
function month($month)
{
	$month=str_replace("01","Jan","$month");
	$month=str_replace("02","Feb","$month");
	$month=str_replace("03","Mar","$month");
	$month=str_replace("04","Apr","$month");
	$month=str_replace("05","May","$month");
	$month=str_replace("06","Jun","$month");
	$month=str_replace("07","Jul","$month");
	$month=str_replace("08","Aug","$month");
	$month=str_replace("09","Sep","$month");
	$month=str_replace("10","Oct","$month");
	$month=str_replace("11","Nov","$month");
	$month=str_replace("12","Dec","$month");
	return $month;
}
?>