<?php
session_start();
if(isset($_SESSION['login_user']))
 header("Location:main.php");
 else
  include_once "front.php";
  ?>
