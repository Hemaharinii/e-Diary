<html>
<head>
<title>Welcome to e-Diary</title>
<link rel="stylesheet" type="text/css" href="hstyle.css" />
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="icon" href="img/favicon.ico" type="image/x-icon">
</head>
<body>
<div class="main">
	<div class="lhs">
		<div class="overlay">
			<img class="logo" src="img/logo.png" alt="logo">
		</div>

	</div>

	<div class="content">
			<div class="container">
               <div class="choice">
					<center>
					<ul class="tab">
					<li id="logintab" class="activetab" onclick="opentab('login')">Login</li>
					<li id="registertab" onclick="opentab('register')">Signup</li>
					</ul>
				  	<div class="clearfix">
					</div>
					<br>

					<form id="logincontents" method="post" action="<?=htmlspecialchars("login.php");?>">
					<input type="text" name="uname" placeholder="Username" required>
					<input type="password" placeholder="Password" name="pass" required>
					<button type="submit" name="submit">Login</button>
					</form>

					<form id="registercontents" class="hidden" method="post" action="<?=htmlspecialchars("register.php");?>">
					<input type="text" name="fname" placeholder="First Name" required>
					<input type="text" name="lname" placeholder="Last Name" required>
					<input type="text" name="uname" placeholder="Username" required>
					<input type="password" placeholder="Password" name="pass" required>
					<input type="password" placeholder="Confirm Password" name="conpass" required>

					<input type="email" placeholder="Email" name="email" required>

					<button type="submit" name="submit">Submit</button><br><br><br>
					</form>
				</center>
			    </div>
			</div>
  	</div>
	<div class="error">
	    <?php
		/*
		{
		echo $_GET['success'];}
          */?>
    </div>
</div>
</body>

<script>
function opentab(x)
  {if(x=="login")
	  y="register";
  else
	  y="login";
  document.getElementById(x+"tab").classList.add("activetab");
  document.getElementById(y+"tab").classList.remove("activetab");
  document.getElementById(y+"contents").classList.add("hidden");
  document.getElementById(x+"contents").classList.remove("hidden");
  }
</script>
</html>
