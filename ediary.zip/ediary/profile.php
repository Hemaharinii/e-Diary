<html>
<?php
include "db.php";
include "functions.php";
 $q="SELECT * FROM users WHERE username = '$uname'";
  $result = mysqli_query($con,$q);
   $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
   $fname=$row["first_name"];
   $lname=$row["last_name"];
   $profile=$row['profile']; 
   ?>
<head>
