<?php
include "db.php";
include "functions.php";
session_start();
if(!isset($_SESSION['login_user']))
	header("Location:front.php");
$uname = $_SESSION['login_user'];
$q="SELECT * FROM users WHERE username = '$uname'";
  $result = mysqli_query($con,$q);
   $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
   $fname=$row["first_name"];
   $lname=$row["last_name"];
   $profile_image=$row['profile_image'];
?>
<html>
<head>
<title> My Space </title>
<link rel="stylesheet" type="text/css" href="mstyle.css" />
</head>
<body>
<div class="main">
	<div class="header">
		<div class="logo">
			<img src = "img/logo.png" alt="logo" >
		</div>
		<div class="search">
			<input type="text" name="search" placeholder = "Looking for something??" /> <img src="img/search.png" alt="search">
		</div>
       <div class="dropdown">
	     <p class="active"> <?php echo $fname." ".$lname;?></p>
	       <div class="dropdown-content">
		    <a href="profile.php">My Profile</a></li>
		    <a href="#">Settings</a></li>
		    <a href="logout.php">Logout</a></li>
		   </div>
	   </div>
    </div>
	<div class="mainContainer">
		<div class="leftContainer">
			<div class="userInfo">
				<div class="proPic">
					<img src="img/avatars/<?=$profile_image;?>" />
				</div>
				<h3><?=$uname;?></h3>
			</div>
		</div>
	    <div class="rightContainer">
			<div class="innerContainer insertContainer">
					<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
						<textarea name="entry" placeholder="The story of your day goes here..." rows="10" cols="50"></textarea><br />
						<button name="enter" type="submit">Go!</button>
					</form>
						<br /><br /><br /><br />
<?php


$d=date("Y-m-d");
$query= "SELECT * FROM entries WHERE username = '$uname' ORDER BY date DESC";
  $result = mysqli_query($con,$query);
   if($result=mysqli_query($con,$query))
   {
	   if(mysqli_num_rows($result)>0)
	   {
		   while($row=mysqli_fetch_array($result))
		   {

	   $dat=$row["date"];
                $date=array();
				$date=explode('-',$dat);
			    $date['1']=month($date['1']);
				$entry=$row["entry"];
				$entry=ed_decrypt($entry);
				$entry=Smilify($entry);
				?>
				<div class="content">
				   <div class="cal">
				       <div class="month">  <?=$date['1'];?>   </div>
					  <b> <?=$date['2']?><br> </b>
					   <?=$date['0']?>
 				 </div>
				<?=$entry?>
			</div>

           <?php
		   }
	   }
   }

if ($_SERVER["REQUEST_METHOD"] == "POST")
 {
	$en = $_POST['entry'];
	$en =ed_encrypt($en);
	$ent = mysqli_real_escape_string($con,$en);

	echo  $d;
	$query= "SELECT entry FROM entries WHERE username='$uname' AND date='$d'";
	$res = mysqli_query($con,$query);
	$count = mysqli_num_rows($res);
    $txt = "";
	if($count)
	{	 //echo "Exists";

	  while($row = mysqli_fetch_row($res))
	  {
	        $txt=$row[0];
	  }
	    $txt=$txt."\n".$en;
		$txt = mysqli_real_escape_string($con,$txt);
	    $query="UPDATE entries SET entry = '$txt' WHERE username = '$uname' AND date='$d' ";
		if(mysqli_query($con,$query))

			{
				header("refresh:1; URL=http://localhost/ediary/main.php");
            }
	}
     else
	  { //echo "Not Exists";
        $query="INSERT INTO entries(username,entry,date) VALUES('$uname','$ent','$d')";
	    if(mysqli_query($con,$query))
		{
			header("refresh:1; URL=http://localhost/ediary/main.php");
		}
	  }
}
?>
    </div>
	</div>
	</div>
</div>
</body>

</html>
