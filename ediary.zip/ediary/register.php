<html>
<head>
<link rel="stylesheet" type="text/css" href="hstyle.css" />
</head>
<?php
require_once "functions.php";
require_once "db.php";
// define variables and set to empty values
$fnameErr = $lnameErr = $unameErr=$emailErr = $passErr = $conpassErr = $matpass= null ;
$fname = $lname = $email = $pass = $conpass = $uname = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
   if (empty($_POST["fname"])) {
     $fnameErr = "Name is required";
   } else {
     $fname = test_input($_POST["fname"]);
     // check if name only contains letters and whitespace
     if (!preg_match("/^[a-zA-Z ]*$/",$fname)) {
       $fnameErr = "Only letters and white space allowed"; 
     }
   }
   if (empty($_POST["lname"])) {
     $fnameErr = "Name is required";
   } else {
     $lname = test_input($_POST["lname"]);
     // check if name only contains letters and whitespace
     if (!preg_match("/^[a-zA-Z ]*$/",$lname)) {
       $lnameErr = "Only letters and white space allowed"; 
     }
   }
   if (empty($_POST["uname"])) {
     $unameErr = "Username is required";
   } else {
	   $uname=$_POST["uname"];
	   $uname=test_input($uname);
	   $uname=$con->real_escape_string($uname);
      $query="SELECT * FROM users WHERE username='$uname'";
       if(mysqli_num_rows(mysqli_query($con,$query))>0)
       {
		   $unameErr="Username already exists!!!!";
		   
	   }		   
	  }
   
   if (empty($_POST["pass"]))
 {   $passErr = "Password is required"; 
 }else {
     $pass = test_input($_POST["pass"]);
 }
 if (empty($_POST["conpass"]))
 {   $conpassErr = "Password is required"; 
 }else {
     $conpass = test_input($_POST["conpass"]);
 }
   if($_POST["pass"]==$_POST["conpass"])
   {
	   $matpass = "";
   }
   else
   {
	$matpass = "Passwords dont match";   
   }
if (empty($_POST["email"])) {
     $emailErr = "Email is required";
   } else {
     $email = test_input($_POST["email"]);
     // check if e-mail address is well-formed
     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
       $emailErr = "Invalid email format"; 
     }
   }
   if(!$fameErr && !$lameErr && !$unameErr && !$passErr && !$matpass && !$emailErr && !$conpassErr)
   {
	    $pass=sha1($pass);
		$query="INSERT INTO users(username,first_name,last_name,email,password) VALUES ('$uname','$fname','$lname','$email','$pass')";
		if(mysqli_query($con,$query))
		{
       	 header("Location:http://localhost/ediary/front.php");
         		 
		}
   }
   else
   {
	 header("Location:http://localhost/ediary/front.php");
   }
}	
?>